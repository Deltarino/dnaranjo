package Alumne;

import junit.framework.*;

public class AlumneTest extends TestCase {
	
	Alumne a1 = new Alumne("Paco", 16, 2016, 10, 8);
	Alumne a2 = new Alumne("Jose", 18, 2013, 3, 4);
	Alumne a3 = new Alumne("Antonio", 42, 2010, 5, 6);
	
	public void testMajorEdat() {
		assertEquals(a1.esMajorEdat(), false);
		assertEquals(a2.esMajorEdat(), true);
		assertEquals(a3.esMajorEdat(), true);
	}
	
	public void testAprovaM5() {
		assertTrue("Retorna un aprovat", a1.aprovaM5(95));
		assertFalse("Retorna un suspes degut a la nota", a2.aprovaM5(85));
		assertFalse("Retorna un suspes per la baixa asistencia", a3.aprovaM5(40));
	}
	
	public void testAnysMatriculat() {
		assertEquals(a1.anysMatriculat(2018), 2);
		assertEquals(a2.anysMatriculat(2018), 5);
		assertEquals(a3.anysMatriculat(2018), 8);
	}
	
	public void testPassaASegon() {
		assertTrue("L'alumne passa a segon", a1.passaASegon());
		assertFalse("No passa a segon", a2.passaASegon());
		assertFalse("No passa a segon", a3.passaASegon());
	}
}
